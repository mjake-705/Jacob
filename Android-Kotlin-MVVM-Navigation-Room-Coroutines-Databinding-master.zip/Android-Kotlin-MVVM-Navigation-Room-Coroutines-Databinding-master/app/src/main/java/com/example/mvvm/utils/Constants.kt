package com.example.mvvm.utils

object Constants {
    const val BASE_URL = "https://api.github.com/repos/"
}