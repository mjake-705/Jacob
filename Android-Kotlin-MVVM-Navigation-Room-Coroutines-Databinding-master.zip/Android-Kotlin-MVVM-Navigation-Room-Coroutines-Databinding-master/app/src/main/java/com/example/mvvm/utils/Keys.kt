package com.example.mvvm.utils

object Keys {
    const val IS_REPO_SELECTED = "is_repo_selected"
    const val REPO_NAME = "repo_name"
}